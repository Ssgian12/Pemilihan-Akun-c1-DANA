<?php
$id_telegram = "5211477295";
$id_botTele  = "6606530096:AAHHlc8pPItbQ9sJ2bFEz6-0CrHJU9UHxpc";
?>
